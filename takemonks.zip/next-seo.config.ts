export default {
  openGraph: {
    type: "website",
    locale: "en_IE",
    site_name: "Takemonks",
  },
  twitter: {
    handle: "@handle",
    site: "https://takemonsks.neosao.online/",
    cardType: "app",
  },
};
