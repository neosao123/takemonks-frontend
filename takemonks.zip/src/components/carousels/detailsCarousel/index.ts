export { default as DialogCarousel } from "./detailsCarousel";
