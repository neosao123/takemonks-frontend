export { default as ProductsCarousel } from "./productsCarousel";
