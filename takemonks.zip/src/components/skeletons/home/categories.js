import React from "react";

export default function mobileCategories() {
  return <div>mobileCategories</div>;
}
