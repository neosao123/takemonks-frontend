
export { default as TableHead } from "./tableHead";

