export const GENDER_OPTION = ["men", "women", "kids", "others"];
export const SIZES = ["XS", "SM", "LG", "XL", "XXL", "free"];
export const COLORS = [
  "aqua",
  "black",
  "blue",
  "brown",
  "gold",
  "grey",
  "green",
  "white",
  "yellow",
];
