// export { default as CategoriesFilter } from "./categoriesFilter";
export { default as ColorsFilter } from "./colorsFilter";
export { default as GenderFilter } from "./genderFilter";
export { default as SizesFilter } from "./sizesFilter";
