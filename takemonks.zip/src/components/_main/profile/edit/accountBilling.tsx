//
import AccountBillingAddressBook from "./accountBillingAddressBook";

// ----------------------------------------------------------------------

export default function AccountBilling() {
  return <AccountBillingAddressBook />;
}
