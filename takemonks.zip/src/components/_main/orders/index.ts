export { default as OrderDetails } from "./orderDetails";
export { default as OrderDetailsTable } from "./tableDetails";
export { default as TableCard } from "./tableCard";
