export { default as Amcslist } from "./amcslist";
