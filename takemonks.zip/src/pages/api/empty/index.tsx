import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "lib/dbConnect";

type Data = {
  success?: boolean;
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  const { method } = req;

  await dbConnect();
  switch (method) {
    case "GET":
      try {
        /* find all the data in our database */
        res.status(200).json({
          success: true,
        });
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;

    default:
      res.status(400).json({ success: false });
      break;
  }
}
