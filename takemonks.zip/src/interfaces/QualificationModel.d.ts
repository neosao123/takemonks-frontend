interface QualificationModel {
  id:string,
  uuid: string;
  status: number;
  order:number;
  title: string;
}