interface AnalysisModel {
    uuid: string,
    name: string,
}
