interface SpecialtyModel {
  uuid: string;
  name: string;
  description: string;
}