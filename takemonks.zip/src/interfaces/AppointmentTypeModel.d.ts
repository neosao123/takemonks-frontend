interface AppointmentTypeModel {
    key: string,
    value: string,
    color: string
}
