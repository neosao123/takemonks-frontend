interface ActModel {
  uuid: string;
  name: string;
  description: string;
  weight: number;
}