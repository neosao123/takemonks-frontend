interface InstructionModel {
  uuid: string;
  name: string;
  description: string;
}