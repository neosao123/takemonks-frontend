interface DurationModel {
    value: number,
    date: number,
    unity: string
}