interface MedicalEntityHasUsersModel {
  uuid: string;
  isPublic: boolean;
  isActive: boolean;
  isAccepted: boolean;
  isOwner: boolean;
}