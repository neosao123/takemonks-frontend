interface FamilyAntecedentsModel {
    ascendantOf: string
    name: string
    startDate: string
    uuid: string
}
