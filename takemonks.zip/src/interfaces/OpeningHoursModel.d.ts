interface OpeningHoursModel {
  isVisible: boolean;
  isMain: boolean;
  openingHours: any;
}