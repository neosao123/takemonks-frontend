interface InsuranceModel {
  uuid: string;
  name: string;
  logo: string;
}