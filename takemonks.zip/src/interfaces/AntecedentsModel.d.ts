interface AntecedentsModel {
    endDate: string
    name: string
    startDate: string
    uuid: string
}
