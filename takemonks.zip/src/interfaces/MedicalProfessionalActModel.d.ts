interface MedicalProfessionalActModel {
  uuid: string;
  isTopAct: boolean;
  act: ActModel;
}