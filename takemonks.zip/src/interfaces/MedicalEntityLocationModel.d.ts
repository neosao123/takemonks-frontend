interface MedicalEntityLocationModel {
  uuid: string;
  isPublic: boolean;
  isActive: boolean;
  address: LocationModel;
}