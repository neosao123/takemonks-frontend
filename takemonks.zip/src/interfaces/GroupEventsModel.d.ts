interface GroupEventsModel {
    date: string;
    events: Array<EventCalendarModel>
}
