interface PrespectionDrugModel {
    dosage: string,
    drugUuid: string
    duration: string
    durationType: string
    name: string
    note: string

}