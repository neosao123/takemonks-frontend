interface PatientInsuranceModel {
  uuid: string;
  insuranceNumber: string;
  insurance: InsuranceModel;
}