interface JsonWidgetModel {
  uuid: string;
  label: string;
  structure: string[];
}