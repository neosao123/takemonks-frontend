interface Qualifications {
    id: number,
    name: string,
    //name_ar: string
}
export default Qualifications;