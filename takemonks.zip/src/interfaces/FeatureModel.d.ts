interface FeatureModel {
  uuid: string;
  name: string;
  category: number;
  slug: string;
}