interface CountryModel {
  uuid: string;
  name: string;
  code: string;
}