interface AddressModel {
  uuid: string;
  street: string;
  postalCode: string;
  location: LocationModel;
  address: Address;
}