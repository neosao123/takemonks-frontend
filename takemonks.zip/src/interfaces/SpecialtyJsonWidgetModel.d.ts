interface SpecialtyJsonWidgetModel {
  uuid: string;
  name: string;
  fieldSet:any;
  jsonWidgets: JsonWidgetModel[];
}