interface WeekTimeSlotsModel {
  date: string;
  day: string;
  slots: TimeSlotModel[];
}
