interface ModalModel {
  label: string;
  color: string;
  uuid: string;
  isEnabled: boolean;
  hasData: boolean;
  structure: any[];
}