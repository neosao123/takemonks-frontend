interface Table {
  patientId: string | null;
  addAmount: string | number;
  patientAction: string;
}
export default Table;
