interface AgendaLocationModel {
    accessInformation: any[];
    address: AddressModel;
    contacts: ContactModel[];
    name: string;
    openingHours: openingHoursModel[];
    uuid: string;
}
