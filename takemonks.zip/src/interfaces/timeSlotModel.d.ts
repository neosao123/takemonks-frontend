interface TimeSlotModel {
  start: string;
  end: string;
  disabled: boolean;
}
