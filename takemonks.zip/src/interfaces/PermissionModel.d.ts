interface PermissionModel {
  uuid: string;
  name: string;
}