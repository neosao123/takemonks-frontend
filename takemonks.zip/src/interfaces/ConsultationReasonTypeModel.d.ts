interface ConsultationReasonTypeModel {
  dayDate: string;
  consultationReason: any;
  patient: any;
  startTime: string;
  uuid: string;
  name: string;
}