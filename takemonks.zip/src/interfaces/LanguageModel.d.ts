interface LanguageModel {
  uuid: string;
  name: string;
  code: string;
}