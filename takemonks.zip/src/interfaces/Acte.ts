interface Acte {
    id: number,
    title: string,
}
export default Acte;