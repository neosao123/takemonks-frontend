interface MedicalEntityDefault {
  is_default : boolean,
  medical_entity: MedicalEntityModel
}
