interface DrugModel {
  uuid: string;
  commercial_name: string;
  isVerified: boolean
}