interface PaymentMeansModel {
  uuid: string;
  name: string;
  logo: string;
}