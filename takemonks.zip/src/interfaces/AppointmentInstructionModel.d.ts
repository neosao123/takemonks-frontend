interface AppointmentInstructionModel {
  description: string;
  smsLang: string;
  rappel: string;
  smsRappel: boolean;
  timeRappel: Date;
}
